#include <iostream>

using namespace std;

int main() {
    int a, b;
    printf("Num 1: ");
    cin >> a;
    printf("Num 2: ");
    cin >> b;

    printf("El producto de \"%i\" y \"%i\" es igual a: %i", a, b, a * b);

    return 0;
}
