#include <iostream>

using namespace std;

int main() {
    float n;
    printf("N: ");
    cin >> n;

    printf("El redondeo es: %.0f\n", n);
    return 0;
}
